window.bookSummaryJSON = "<p>The question is, how can you <i>tell</i> the President's brain is missing? And are we sure we need it back?</p>"; 
